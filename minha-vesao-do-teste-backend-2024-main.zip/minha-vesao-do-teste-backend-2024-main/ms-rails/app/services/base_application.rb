module Services
  class BaseApplication
  end
end