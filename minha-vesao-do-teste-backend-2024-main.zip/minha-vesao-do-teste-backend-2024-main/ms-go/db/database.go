package db

import (
	"context"
	"fmt"
	"log"
	"sync"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var (
	db     *mongo.Collection
	client *mongo.Client
	once   sync.Once
)

// Connection estabelece a conexão com o MongoDB e retorna a coleção "products"
func Connection() *mongo.Collection {
	once.Do(func() {
		// Configurações do cliente MongoDB
		clientOptions := options.Client().ApplyURI("mongodb://localhost:27017")

		// Conecta ao MongoDB
		var err error
		client, err = mongo.Connect(context.Background(), clientOptions)
		if err != nil {
			log.Fatalf("Erro ao conectar ao MongoDB: %v", err)
		}

		// Verifica a conexão
		err = client.Ping(context.Background(), nil)
		if err != nil {
			log.Fatalf("Erro ao pingar o MongoDB: %v", err)
		}

		// Define a coleção
		db = client.Database("teste_backend").Collection("products")
	})

	return db
}

// Disconnect desconecta do MongoDB
func Disconnect() {
	if client != nil {
		err := client.Disconnect(context.Background())
		if err != nil {
			log.Fatalf("Erro ao desconectar do MongoDB: %v", err)
		}
	}
}