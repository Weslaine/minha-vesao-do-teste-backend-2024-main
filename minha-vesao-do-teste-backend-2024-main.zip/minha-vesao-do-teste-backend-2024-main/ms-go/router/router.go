package router

import (
	"fmt"
	"log"
	"ms-go/app/controller"

	"github.com/gin-gonic/gin"
)

// Run inicializa o servidor HTTP na porta 3030
func Run() {
	r := SetupRouter()

	fmt.Println("* Listening on tcp://localhost:3030")

	if err := r.Run(":3030"); err != nil {
		log.Fatal("Unable to start the server")
	}
}

// SetupRouter configura todas as rotas da aplicação utilizando Gin
func SetupRouter() *gin.Engine {
	router := gin.Default() // Cria um roteador Gin com logger e recovery padrão

	// Rota inicial para verificar se o servidor está funcionando
	router.GET("/", controller.IndexHome)

	// Grupo de rotas /api/v1 para endpoints relacionados a produtos
	apiV1 := router.Group("/api/v1")
	{
		apiV1.GET("/products", controller.IndexProducts)     // Lista todos os produtos
		apiV1.GET("/products/:id", controller.ShowProducts)  // Mostra detalhes de um produto específico
		apiV1.POST("/products", controller.CreateProducts)   // Cria um novo produto
		apiV1.PATCH("/products/:id", controller.UpdateProducts) // Atualiza um produto existente
	}

	// Rota para lidar com casos em que nenhum dos endpoints corresponde
	router.NoRoute(func(c *gin.Context) {
		c.JSON(404, gin.H{"error": "Page not found"})
	})

	return router
}