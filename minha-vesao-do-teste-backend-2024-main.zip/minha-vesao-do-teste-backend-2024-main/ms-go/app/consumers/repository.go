package repository

import (
	"your_project/models"
)

type ProductRepository interface {
	GetAllProducts() ([]models.Product, error)
	GetProductByID(id int) (*models.Product, error)
	CreateProduct(product *models.Product) error
	UpdateProduct(product *models.Product) error
	DeleteProduct(id int) error
}

// Implementação do repositório usando um banco de dados (por exemplo, MongoDB, PostgreSQL, etc.)
type ProductRepositoryImpl struct {
	// Adicione aqui a conexão com o banco de dados
}

// Implemente os métodos da interface ProductRepository
