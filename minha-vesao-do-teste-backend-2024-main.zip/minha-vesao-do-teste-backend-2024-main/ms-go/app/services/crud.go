package repository

import (
	"database/sql"
	"your_project/models"
)

type ProductRepository struct {
	DB *sql.DB
}

func (r *ProductRepository) CreateProduct(product *models.Product) error {
	query := `
		INSERT INTO products (name, brand, price, description, stock, created_at, updated_at)
		VALUES (?, ?, ?, ?, ?, ?, ?)
	`
	_, err := r.DB.Exec(query, product.Name, product.Brand, product.Price, product.Description, product.Stock, product.CreatedAt, product.UpdatedAt)
	return err
}
