package products

import (
	"context"
	"ms-go/app/helpers"
	"ms-go/app/models"
	"ms-go/db"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
)

func Update(data models.Product, isAPI bool) (*models.Product, error) {
	if data.ID == 0 {
		return nil, &helpers.GenericError{Msg: "Missing parameters", Code: http.StatusUnprocessableEntity}
	}

	var product models.Product

	// Encontra o produto pelo ID
	if err := db.Connection().FindOne(context.TODO(), bson.M{"id": data.ID}).Decode(&product); err != nil {
		return nil, &helpers.GenericError{Msg: "Product Not Found", Code: http.StatusNotFound}
	}

	// Define a data de atualização
	data.UpdatedAt = time.Now()

	// Aplica as atualizações no produto existente
	setUpdate(&data, &product)

	// Executa a atualização no banco de dados
	if err := db.Connection().FindOneAndUpdate(context.TODO(), bson.M{"id": data.ID}, bson.M{"$set": data}).Decode(&product); err != nil {
		return nil, &helpers.GenericError{Msg: err.Error(), Code: http.StatusInternalServerError}
	}

	// Reconsulta o produto atualizado
	if err := db.Connection().FindOne(context.TODO(), bson.M{"id": data.ID}).Decode(&product); err != nil {
		return nil, &helpers.GenericError{Msg: "Product Not Found", Code: http.StatusNotFound}
	}

	defer db.Disconnect()

	if isAPI {
		// Aqui você pode implementar lógica adicional para integrar com a mensageria, se necessário
		// Exemplo: publishMessage(data)
	}

	return &product, nil
}

// Função auxiliar para aplicar atualizações apenas nos campos não vazios
func setUpdate(new, old *models.Product) {
	if new.Name == "" {
		new.Name = old.Name
	}

	if new.Brand == "" {
		new.Brand = old.Brand
	}

	if new.Price == 0 {
		new.Price = old.Price
	}

	if new.Description == "" {
		new.Description = old.Description
	}

	// Mantém os valores de CreatedAt e ID do produto original
	new.CreatedAt = old.CreatedAt
	new.ID = old.ID

	// Atualiza a data de atualização para o momento atual
	new.UpdatedAt = time.Now()
}