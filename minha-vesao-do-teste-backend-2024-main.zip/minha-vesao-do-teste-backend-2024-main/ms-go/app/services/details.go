package main

import (
	"ms-go/app/controllers"
	"ms-go/app/services"
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/streadway/amqp"
)

func main() {
	r := gin.Default()

	// MongoDB connection
	mongoClient, err := services.ConnectMongo()
	if err != nil {
		log.Fatalf("Could not connect to MongoDB: %v", err)
	}
	defer mongoClient.Disconnect(nil)

	// RabbitMQ connection
	conn, err := amqp.Dial(os.Getenv("RABBITMQ_URL"))
	if err != nil {
		log.Fatalf("Could not connect to RabbitMQ: %v", err)
	}
	defer conn.Close()

	ch, err := conn.Channel()
	if err != nil {
		log.Fatalf("Could not open a channel: %v", err)
	}
	defer ch.Close()

	// Start consumer
	go services.StartConsumer(ch, mongoClient)

	// Routes
	r.GET("/", controllers.IndexHome)
	r.GET("/products", controllers.IndexProducts)
	r.GET("/products/:id", controllers.ShowProducts)
	r.POST("/products", controllers.CreateProducts)
	r.PUT("/products/:id", controllers.UpdateProducts)

	// Start server
	r.Run(":8080")
}