package controller_test

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"ms-go/app/controller"
)

func TestIndexHome(t *testing.T) {
	// Cria um roteador Gin com configuração padrão
	router := gin.Default()

	// Configura a rota GET para "/"
	router.GET("/", controller.IndexHome)

	// Cria uma solicitação GET para a rota "/"
	req, err := http.NewRequest(http.MethodGet, "/", nil)
	if err != nil {
		t.Fatalf("Falha ao criar requisição: %v", err)
	}

	// Cria um gravador de resposta para capturar a resposta HTTP
	w := httptest.NewRecorder()

	// Serve a requisição HTTP e grava a resposta
	router.ServeHTTP(w, req)

	// Verifica se o código de status da resposta é 200 OK
	assert.Equal(t, http.StatusOK, w.Code, "O código de status deve ser 200")

	// Converte o corpo da resposta JSON para um mapa para facilitar a verificação
	var response map[string]interface{}
	err = json.Unmarshal(w.Body.Bytes(), &response)
	if err != nil {
		t.Fatalf("Falha ao decodificar resposta JSON: %v", err)
	}

	// Verifica se a mensagem na resposta é a esperada
	expectedMessage := "[ms-go] | Success"
	actualMessage := response["message"].(string)
	assert.Equal(t, expectedMessage, actualMessage, "A mensagem deve corresponder ao esperado")
}